import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  products: router({
    list: publicProcedure.query(async () => {
      return await db.getAllProducts();
    }),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getProductById(input.id);
      }),
  }),

  orders: router({
    create: publicProcedure
      .input(
        z.object({
          productId: z.number(),
          quantity: z.number().min(1),
          productType: z.enum(["digital", "physical"]),
          email: z.string().email().optional(),
          customerName: z.string().optional(),
          phone: z.string().optional(),
          city: z.string().optional(),
          address: z.string().optional(),
          notes: z.string().optional(),
          paymentMethod: z.enum(["asiaCel", "masterCard", "cashOnDelivery"]),
        })
      )
      .mutation(async ({ input }) => {
        // Get product
        const product = await db.getProductById(input.productId);
        if (!product) {
          throw new Error("Product not found");
        }

        // Check stock
        if (product.stock < input.quantity) {
          throw new Error("Insufficient stock");
        }

        // Generate order number
        const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;

        // Calculate total
        const totalAmount = product.price * input.quantity;

        // Create order
        await db.createOrder({
          orderNumber,
          productType: input.productType,
          email: input.email,
          customerName: input.customerName,
          phone: input.phone,
          city: input.city,
          address: input.address,
          notes: input.notes,
          paymentMethod: input.paymentMethod,
          totalAmount,
          status: "pending",
        });

        // Get the created order
        const order = await db.getOrderByNumber(orderNumber);
        if (!order) {
          throw new Error("Failed to create order");
        }

        // Create order item
        await db.createOrderItem({
          orderId: order.id,
          productId: product.id,
          productName: product.name,
          quantity: input.quantity,
          price: product.price,
        });

        // Update product stock
        await db.updateProduct(product.id, {
          stock: product.stock - input.quantity,
        });

        return { orderNumber, orderId: order.id };
      }),

    getByNumber: publicProcedure
      .input(z.object({ orderNumber: z.string() }))
      .query(async ({ input }) => {
        const order = await db.getOrderByNumber(input.orderNumber);
        if (!order) return null;

        const items = await db.getOrderItems(order.id);
        return { ...order, items };
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      // Only admin can list all orders
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized");
      }
      return await db.getAllOrders();
    }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum(["pending", "processing", "completed", "cancelled"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Only admin can update order status
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized");
        }
        await db.updateOrderStatus(input.id, input.status);
        return { success: true };
      }),
  }),

  admin: router({
    createProduct: adminProcedure
      .input(
        z.object({
          name: z.string(),
          description: z.string().optional(),
          price: z.number(),
          type: z.enum(["digital", "physical"]),
          imageUrl: z.string().optional(),
          stock: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        await db.createProduct({
          name: input.name,
          description: input.description,
          price: input.price,
          type: input.type,
          imageUrl: input.imageUrl,
          stock: input.stock,
          isActive: 1,
        });
        return { success: true };
      }),

    updateProduct: adminProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          description: z.string().optional(),
          price: z.number().optional(),
          type: z.enum(["digital", "physical"]).optional(),
          imageUrl: z.string().optional(),
          stock: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateProduct(id, data);
        return { success: true };
      }),

    deleteProduct: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteProduct(input.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
