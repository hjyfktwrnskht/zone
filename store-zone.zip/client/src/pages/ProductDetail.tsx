import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { trpc } from "@/lib/trpc";
import { ArrowRight, ShoppingCart, Package, CreditCard } from "lucide-react";
import { Link, useParams, useLocation } from "wouter";
import { APP_TITLE } from "@/const";
import { useState } from "react";
import { toast } from "sonner";

export default function ProductDetail() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const productId = parseInt(params.id || "0");
  
  const { data: product, isLoading } = trpc.products.getById.useQuery({ id: productId });
  const createOrderMutation = trpc.orders.create.useMutation();

  const [quantity, setQuantity] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState<"asiaCel" | "masterCard" | "cashOnDelivery">("asiaCel");
  
  // Digital product fields
  const [email, setEmail] = useState("");
  
  // Physical product fields
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!product) return;

    // Validation
    if (product.type === "digital" && !email) {
      toast.error("يرجى إدخال البريد الإلكتروني");
      return;
    }
    
    if (product.type === "physical") {
      if (!customerName || !phone || !city || !address) {
        toast.error("يرجى ملء جميع الحقول المطلوبة");
        return;
      }
    }

    if (quantity < 1 || quantity > product.stock) {
      toast.error("الكمية غير صحيحة");
      return;
    }

    try {
      const result = await createOrderMutation.mutateAsync({
        productId: product.id,
        quantity,
        productType: product.type,
        email: product.type === "digital" ? email : undefined,
        customerName: product.type === "physical" ? customerName : undefined,
        phone: product.type === "physical" ? phone : undefined,
        city: product.type === "physical" ? city : undefined,
        address: product.type === "physical" ? address : undefined,
        notes: product.type === "physical" ? notes : undefined,
        paymentMethod: product.type === "digital" ? paymentMethod : "cashOnDelivery",
      });

      toast.success("تم إنشاء الطلب بنجاح!");
      setLocation(`/order/${result.orderNumber}`);
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء الطلب");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container py-4">
            <Link href="/">
              <Button variant="ghost">
                <ArrowRight className="ml-2 h-4 w-4" />
                العودة للرئيسية
              </Button>
            </Link>
          </div>
        </header>
        <div className="container py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded w-1/3 mb-4" />
            <div className="h-64 bg-muted rounded mb-4" />
            <div className="h-4 bg-muted rounded w-full mb-2" />
            <div className="h-4 bg-muted rounded w-2/3" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container py-4">
            <Link href="/">
              <Button variant="ghost">
                <ArrowRight className="ml-2 h-4 w-4" />
                العودة للرئيسية
              </Button>
            </Link>
          </div>
        </header>
        <div className="container py-16 text-center">
          <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-foreground mb-2">المنتج غير موجود</h2>
          <p className="text-muted-foreground mb-6">لم نتمكن من العثور على المنتج المطلوب</p>
          <Link href="/">
            <Button>العودة للرئيسية</Button>
          </Link>
        </div>
      </div>
    );
  }

  const totalPrice = product.price * quantity;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container py-4">
          <Link href="/">
            <Button variant="ghost">
              <ArrowRight className="ml-2 h-4 w-4" />
              العودة للرئيسية
            </Button>
          </Link>
        </div>
      </header>

      <div className="container py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Product Info */}
          <div>
            <Card>
              <CardHeader>
                {product.imageUrl && (
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-96 object-cover rounded-md mb-4"
                  />
                )}
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-2xl">{product.name}</CardTitle>
                  <Badge variant={product.type === "digital" ? "default" : "secondary"}>
                    {product.type === "digital" ? "منتج رقمي" : "منتج مادي"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">{product.description}</p>
                <div className="flex items-center justify-between">
                  <p className="text-3xl font-bold text-primary">
                    {(product.price / 100).toLocaleString("ar-IQ")} د.ع
                  </p>
                  {product.stock > 0 ? (
                    <p className="text-sm text-muted-foreground">
                      متوفر: {product.stock} قطعة
                    </p>
                  ) : (
                    <p className="text-sm text-destructive">نفذت الكمية</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Order Form */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>إتمام الطلب</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Quantity */}
                  <div>
                    <Label htmlFor="quantity">الكمية</Label>
                    <Input
                      id="quantity"
                      type="number"
                      min="1"
                      max={product.stock}
                      value={quantity}
                      onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                      disabled={product.stock === 0}
                    />
                  </div>

                  {/* Digital Product Fields */}
                  {product.type === "digital" && (
                    <>
                      <div>
                        <Label htmlFor="email">البريد الإلكتروني *</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="example@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                        />
                        <p className="text-sm text-muted-foreground mt-1">
                          سيتم إرسال المنتج الرقمي إلى هذا البريد
                        </p>
                      </div>

                      <div>
                        <Label>طريقة الدفع *</Label>
                        <RadioGroup value={paymentMethod} onValueChange={(v) => setPaymentMethod(v as any)}>
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <RadioGroupItem value="asiaCel" id="asiaCel" />
                            <Label htmlFor="asiaCel" className="cursor-pointer">آسيا سيل</Label>
                          </div>
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <RadioGroupItem value="masterCard" id="masterCard" />
                            <Label htmlFor="masterCard" className="cursor-pointer">ماستر كارد</Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </>
                  )}

                  {/* Physical Product Fields */}
                  {product.type === "physical" && (
                    <>
                      <div>
                        <Label htmlFor="customerName">الاسم الكامل *</Label>
                        <Input
                          id="customerName"
                          type="text"
                          placeholder="أدخل اسمك الكامل"
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="phone">رقم الهاتف *</Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="07XX XXX XXXX"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="city">المدينة *</Label>
                        <Input
                          id="city"
                          type="text"
                          placeholder="بغداد، البصرة، إلخ"
                          value={city}
                          onChange={(e) => setCity(e.target.value)}
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="address">العنوان الكامل *</Label>
                        <Textarea
                          id="address"
                          placeholder="أدخل العنوان بالتفصيل"
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="notes">ملاحظات (اختياري)</Label>
                        <Textarea
                          id="notes"
                          placeholder="أي ملاحظات إضافية"
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                        />
                      </div>

                      <div className="bg-muted/50 p-4 rounded-md">
                        <p className="text-sm font-medium">طريقة الدفع: الدفع عند الاستلام</p>
                      </div>
                    </>
                  )}

                  {/* Total */}
                  <div className="border-t pt-4">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-lg font-medium">المجموع الكلي:</span>
                      <span className="text-2xl font-bold text-primary">
                        {(totalPrice / 100).toLocaleString("ar-IQ")} د.ع
                      </span>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full"
                    size="lg"
                    disabled={product.stock === 0 || createOrderMutation.isPending}
                  >
                    {createOrderMutation.isPending ? (
                      "جاري إنشاء الطلب..."
                    ) : (
                      <>
                        <ShoppingCart className="ml-2 h-5 w-5" />
                        تأكيد الطلب
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
