import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { ShoppingCart, Package, Zap } from "lucide-react";
import { Link } from "wouter";
import { APP_TITLE } from "@/const";

export default function Home() {
  const { data: products, isLoading } = trpc.products.list.useQuery();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container py-4">
          <div className="flex items-center gap-2">
            <ShoppingCart className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-bold text-foreground">{APP_TITLE}</h1>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-b from-primary/5 to-background py-16">
        <div className="container text-center">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            مرحباً بك في ستور زون
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            منصتك الموثوقة لشراء المنتجات الرقمية والمادية
          </p>
          <div className="flex justify-center gap-4">
            <a href="#products">
              <Button size="lg">
                <Package className="ml-2 h-5 w-5" />
                تصفح المنتجات
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-12 bg-muted/30">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <Zap className="h-10 w-10 text-primary mb-2" />
                <CardTitle>توصيل سريع</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  المنتجات الرقمية تصلك فوراً عبر البريد الإلكتروني
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Package className="h-10 w-10 text-primary mb-2" />
                <CardTitle>شحن آمن</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  نوصل المنتجات المادية إلى باب منزلك بأمان
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <ShoppingCart className="h-10 w-10 text-primary mb-2" />
                <CardTitle>دفع مرن</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  خيارات دفع متعددة: آسيا سيل، ماستر كارد، أو الدفع عند الاستلام
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-16">
        <div className="container">
          <h2 className="text-3xl font-bold text-foreground mb-8 text-center">
            المنتجات المتاحة
          </h2>
          
          {isLoading ? (
            <div className="grid md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader>
                    <div className="h-48 bg-muted rounded-md mb-4" />
                    <div className="h-6 bg-muted rounded w-3/4" />
                  </CardHeader>
                  <CardContent>
                    <div className="h-4 bg-muted rounded w-full mb-2" />
                    <div className="h-4 bg-muted rounded w-2/3" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : products && products.length > 0 ? (
            <div className="grid md:grid-cols-3 gap-6">
              {products.map((product) => (
                <Card key={product.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    {product.imageUrl && (
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="w-full h-48 object-cover rounded-md mb-4"
                      />
                    )}
                    <div className="flex items-start justify-between gap-2">
                      <CardTitle className="text-lg">{product.name}</CardTitle>
                      <Badge variant={product.type === "digital" ? "default" : "secondary"}>
                        {product.type === "digital" ? "رقمي" : "مادي"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground text-sm line-clamp-2">
                      {product.description}
                    </p>
                    <p className="text-2xl font-bold text-primary mt-4">
                      {(product.price / 100).toLocaleString("ar-IQ")} د.ع
                    </p>
                    {product.stock > 0 ? (
                      <p className="text-sm text-muted-foreground mt-1">
                        متوفر: {product.stock} قطعة
                      </p>
                    ) : (
                      <p className="text-sm text-destructive mt-1">نفذت الكمية</p>
                    )}
                  </CardContent>
                  <CardFooter>
                    <Link href={`/product/${product.id}`} className="w-full">
                      <Button className="w-full" disabled={product.stock === 0}>
                        <ShoppingCart className="ml-2 h-4 w-4" />
                        {product.stock > 0 ? "اطلب الآن" : "غير متوفر"}
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-xl text-muted-foreground">
                لا توجد منتجات متاحة حالياً
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-card py-8 mt-16">
        <div className="container text-center">
          <p className="text-muted-foreground">
            © 2025 {APP_TITLE}. جميع الحقوق محفوظة.
          </p>
        </div>
      </footer>
    </div>
  );
}
