import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { Package, Mail, Phone, MapPin } from "lucide-react";
import { toast } from "sonner";

export default function OrdersManagement() {
  const utils = trpc.useUtils();
  const { data: orders, isLoading } = trpc.orders.list.useQuery();
  const updateStatusMutation = trpc.orders.updateStatus.useMutation();

  const handleStatusChange = async (orderId: number, status: "pending" | "processing" | "completed" | "cancelled") => {
    try {
      await updateStatusMutation.mutateAsync({ id: orderId, status });
      toast.success("تم تحديث حالة الطلب");
      utils.orders.list.invalidate();
    } catch (error) {
      toast.error("حدث خطأ أثناء تحديث حالة الطلب");
    }
  };

  const statusColors = {
    pending: "default",
    processing: "secondary",
    completed: "default",
    cancelled: "destructive",
  } as const;

  const statusLabels = {
    pending: "قيد الانتظار",
    processing: "قيد المعالجة",
    completed: "مكتمل",
    cancelled: "ملغي",
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-muted rounded w-1/3" />
            </CardHeader>
            <CardContent>
              <div className="h-4 bg-muted rounded w-full mb-2" />
              <div className="h-4 bg-muted rounded w-2/3" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!orders || orders.length === 0) {
    return (
      <div className="text-center py-12">
        <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
        <p className="text-xl text-muted-foreground">لا توجد طلبات بعد</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-foreground mb-6">الطلبات</h2>
      
      {orders.map((order) => (
        <Card key={order.id}>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-lg">
                  طلب رقم: <span className="font-mono">{order.orderNumber}</span>
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  {new Date(order.createdAt).toLocaleString("ar-IQ")}
                </p>
              </div>
              <Badge variant={order.productType === "digital" ? "default" : "secondary"}>
                {order.productType === "digital" ? "رقمي" : "مادي"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Order Total */}
            <div className="flex justify-between items-center pb-4 border-b">
              <span className="font-medium">المبلغ الإجمالي:</span>
              <span className="text-xl font-bold text-primary">
                {(order.totalAmount / 100).toLocaleString("ar-IQ")} د.ع
              </span>
            </div>

            {/* Payment Method */}
            <div>
              <span className="font-medium">طريقة الدفع: </span>
              <span>
                {order.paymentMethod === "asiaCel" && "آسيا سيل"}
                {order.paymentMethod === "masterCard" && "ماستر كارد"}
                {order.paymentMethod === "cashOnDelivery" && "الدفع عند الاستلام"}
              </span>
            </div>

            {/* Digital Product Info */}
            {order.productType === "digital" && order.email && (
              <div className="bg-primary/10 p-3 rounded-md">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-primary" />
                  <span className="text-sm">
                    البريد الإلكتروني: <span className="font-mono">{order.email}</span>
                  </span>
                </div>
              </div>
            )}

            {/* Physical Product Info */}
            {order.productType === "physical" && (
              <div className="bg-muted/50 p-3 rounded-md space-y-2">
                <p className="font-semibold text-sm">معلومات الشحن:</p>
                <div className="space-y-1 text-sm">
                  {order.customerName && (
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-muted-foreground" />
                      <span>{order.customerName}</span>
                    </div>
                  )}
                  {order.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span dir="ltr">{order.phone}</span>
                    </div>
                  )}
                  {order.city && (
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{order.city}</span>
                    </div>
                  )}
                  {order.address && (
                    <div className="flex items-start gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <span>{order.address}</span>
                    </div>
                  )}
                </div>
                {order.notes && (
                  <div className="pt-2 border-t">
                    <p className="font-semibold text-sm mb-1">ملاحظات:</p>
                    <p className="text-sm text-muted-foreground">{order.notes}</p>
                  </div>
                )}
              </div>
            )}

            {/* Status Update */}
            <div className="flex items-center gap-4 pt-4 border-t">
              <span className="font-medium">حالة الطلب:</span>
              <Select
                value={order.status}
                onValueChange={(v) => handleStatusChange(order.id, v as any)}
                disabled={updateStatusMutation.isPending}
              >
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">قيد الانتظار</SelectItem>
                  <SelectItem value="processing">قيد المعالجة</SelectItem>
                  <SelectItem value="completed">مكتمل</SelectItem>
                  <SelectItem value="cancelled">ملغي</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
