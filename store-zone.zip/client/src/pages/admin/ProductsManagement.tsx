import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Plus, Edit, Trash2, Package } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function ProductsManagement() {
  const utils = trpc.useUtils();
  const { data: products, isLoading } = trpc.products.list.useQuery();
  const createProductMutation = trpc.admin.createProduct.useMutation();
  const updateProductMutation = trpc.admin.updateProduct.useMutation();
  const deleteProductMutation = trpc.admin.deleteProduct.useMutation();

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);

  // Form state
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [type, setType] = useState<"digital" | "physical">("digital");
  const [imageUrl, setImageUrl] = useState("");
  const [stock, setStock] = useState("");

  const resetForm = () => {
    setName("");
    setDescription("");
    setPrice("");
    setType("digital");
    setImageUrl("");
    setStock("");
    setEditingProduct(null);
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !price || !stock) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    try {
      await createProductMutation.mutateAsync({
        name,
        description,
        price: Math.round(parseFloat(price) * 100),
        type,
        imageUrl: imageUrl || undefined,
        stock: parseInt(stock),
      });

      toast.success("تم إضافة المنتج بنجاح");
      setIsCreateDialogOpen(false);
      resetForm();
      utils.products.list.invalidate();
    } catch (error) {
      toast.error("حدث خطأ أثناء إضافة المنتج");
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingProduct || !name || !price || !stock) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    try {
      await updateProductMutation.mutateAsync({
        id: editingProduct.id,
        name,
        description,
        price: Math.round(parseFloat(price) * 100),
        type,
        imageUrl: imageUrl || undefined,
        stock: parseInt(stock),
      });

      toast.success("تم تحديث المنتج بنجاح");
      setEditingProduct(null);
      resetForm();
      utils.products.list.invalidate();
    } catch (error) {
      toast.error("حدث خطأ أثناء تحديث المنتج");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("هل أنت متأكد من حذف هذا المنتج؟")) {
      return;
    }

    try {
      await deleteProductMutation.mutateAsync({ id });
      toast.success("تم حذف المنتج بنجاح");
      utils.products.list.invalidate();
    } catch (error) {
      toast.error("حدث خطأ أثناء حذف المنتج");
    }
  };

  const openEditDialog = (product: any) => {
    setEditingProduct(product);
    setName(product.name);
    setDescription(product.description || "");
    setPrice((product.price / 100).toString());
    setType(product.type);
    setImageUrl(product.imageUrl || "");
    setStock(product.stock.toString());
  };

  if (isLoading) {
    return (
      <div className="grid md:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-muted rounded w-3/4" />
            </CardHeader>
            <CardContent>
              <div className="h-4 bg-muted rounded w-full mb-2" />
              <div className="h-4 bg-muted rounded w-2/3" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-foreground">المنتجات</h2>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="ml-2 h-4 w-4" />
              إضافة منتج جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>إضافة منتج جديد</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <Label htmlFor="name">اسم المنتج *</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="description">الوصف</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="price">السعر (دينار عراقي) *</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="stock">الكمية المتوفرة *</Label>
                  <Input
                    id="stock"
                    type="number"
                    value={stock}
                    onChange={(e) => setStock(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="type">نوع المنتج *</Label>
                <Select value={type} onValueChange={(v) => setType(v as any)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="digital">رقمي</SelectItem>
                    <SelectItem value="physical">مادي</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="imageUrl">رابط الصورة</Label>
                <Input
                  id="imageUrl"
                  type="url"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              <Button type="submit" className="w-full" disabled={createProductMutation.isPending}>
                {createProductMutation.isPending ? "جاري الإضافة..." : "إضافة المنتج"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {products && products.length > 0 ? (
        <div className="grid md:grid-cols-3 gap-6">
          {products.map((product) => (
            <Card key={product.id}>
              <CardHeader>
                {product.imageUrl && (
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="w-full h-48 object-cover rounded-md mb-4"
                  />
                )}
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-lg">{product.name}</CardTitle>
                  <Badge variant={product.type === "digital" ? "default" : "secondary"}>
                    {product.type === "digital" ? "رقمي" : "مادي"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm line-clamp-2 mb-2">
                  {product.description}
                </p>
                <p className="text-xl font-bold text-primary">
                  {(product.price / 100).toLocaleString("ar-IQ")} د.ع
                </p>
                <p className="text-sm text-muted-foreground">
                  الكمية: {product.stock}
                </p>
              </CardContent>
              <CardFooter className="gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => openEditDialog(product)}
                    >
                      <Edit className="ml-2 h-4 w-4" />
                      تعديل
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>تعديل المنتج</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleUpdate} className="space-y-4">
                      <div>
                        <Label htmlFor="edit-name">اسم المنتج *</Label>
                        <Input
                          id="edit-name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          required
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="edit-description">الوصف</Label>
                        <Textarea
                          id="edit-description"
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          rows={3}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="edit-price">السعر (دينار عراقي) *</Label>
                          <Input
                            id="edit-price"
                            type="number"
                            step="0.01"
                            value={price}
                            onChange={(e) => setPrice(e.target.value)}
                            required
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="edit-stock">الكمية المتوفرة *</Label>
                          <Input
                            id="edit-stock"
                            type="number"
                            value={stock}
                            onChange={(e) => setStock(e.target.value)}
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="edit-type">نوع المنتج *</Label>
                        <Select value={type} onValueChange={(v) => setType(v as any)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="digital">رقمي</SelectItem>
                            <SelectItem value="physical">مادي</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="edit-imageUrl">رابط الصورة</Label>
                        <Input
                          id="edit-imageUrl"
                          type="url"
                          value={imageUrl}
                          onChange={(e) => setImageUrl(e.target.value)}
                          placeholder="https://example.com/image.jpg"
                        />
                      </div>

                      <Button type="submit" className="w-full" disabled={updateProductMutation.isPending}>
                        {updateProductMutation.isPending ? "جاري التحديث..." : "حفظ التغييرات"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>
                
                <Button
                  variant="destructive"
                  size="sm"
                  className="flex-1"
                  onClick={() => handleDelete(product.id)}
                  disabled={deleteProductMutation.isPending}
                >
                  <Trash2 className="ml-2 h-4 w-4" />
                  حذف
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <p className="text-xl text-muted-foreground mb-4">لا توجد منتجات</p>
          <Button onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="ml-2 h-4 w-4" />
            إضافة أول منتج
          </Button>
        </div>
      )}
    </div>
  );
}
