import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_TITLE } from "@/const";
import { Loader2, Package, ShoppingBag, LogOut, BarChart3 } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import ProductsManagement from "./admin/ProductsManagement";
import OrdersManagement from "./admin/OrdersManagement";

export default function AdminDashboard() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"products" | "orders" | "stats">("stats");

  const { data: products } = trpc.products.list.useQuery();
  const { data: orders } = trpc.orders.list.useQuery();

  useEffect(() => {
    const isPasswordVerified = sessionStorage.getItem("admin_password_verified");
    if (isPasswordVerified !== "true") {
      setLocation("/admin");
      return;
    }
    if (!loading && !isAuthenticated) {
      setLocation("/admin/login");
    }
  }, [loading, isAuthenticated, setLocation]);

  useEffect(() => {
    if (!loading && user && user.role !== "admin") {
      setLocation("/");
    }
  }, [loading, user, setLocation]);

  const handleLogout = () => {
    logout();
    sessionStorage.removeItem("admin_password_verified");
    setLocation("/admin");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return null;
  }

  // Calculate stats
  const totalProducts = products?.length || 0;
  const totalOrders = orders?.length || 0;
  const pendingOrders = orders?.filter(o => o.status === "pending").length || 0;
  const completedOrders = orders?.filter(o => o.status === "completed").length || 0;
  const totalRevenue = orders?.reduce((sum, order) => sum + order.totalAmount, 0) || 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-primary/10">
      {/* Sidebar */}
      <aside className="fixed right-0 top-0 h-full w-64 bg-card border-l border-border shadow-lg z-50">
        <div className="p-6">
          <div className="flex items-center gap-2 mb-8">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <ShoppingBag className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-foreground">{APP_TITLE}</h1>
              <p className="text-xs text-muted-foreground">لوحة التحكم</p>
            </div>
          </div>

          <nav className="space-y-2">
            <button
              onClick={() => setActiveTab("stats")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                activeTab === "stats"
                  ? "bg-primary text-primary-foreground"
                  : "hover:bg-muted text-foreground"
              }`}
            >
              <BarChart3 className="h-5 w-5" />
              <span className="font-medium">الإحصائيات</span>
            </button>
            
            <button
              onClick={() => setActiveTab("products")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                activeTab === "products"
                  ? "bg-primary text-primary-foreground"
                  : "hover:bg-muted text-foreground"
              }`}
            >
              <Package className="h-5 w-5" />
              <span className="font-medium">المنتجات</span>
            </button>
            
            <button
              onClick={() => setActiveTab("orders")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                activeTab === "orders"
                  ? "bg-primary text-primary-foreground"
                  : "hover:bg-muted text-foreground"
              }`}
            >
              <ShoppingBag className="h-5 w-5" />
              <span className="font-medium">الطلبات</span>
              {pendingOrders > 0 && (
                <span className="mr-auto bg-destructive text-destructive-foreground text-xs px-2 py-1 rounded-full">
                  {pendingOrders}
                </span>
              )}
            </button>
          </nav>
        </div>

        <div className="absolute bottom-0 right-0 w-full p-6 border-t border-border">
          <div className="mb-4 p-3 bg-muted/50 rounded-lg">
            <p className="text-sm font-medium text-foreground">{user.name || user.email}</p>
            <p className="text-xs text-muted-foreground">مدير النظام</p>
          </div>
          <Button
            variant="outline"
            className="w-full"
            onClick={handleLogout}
          >
            <LogOut className="ml-2 h-4 w-4" />
            تسجيل الخروج
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="mr-64 p-8">
        {activeTab === "stats" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-2">لوحة الإحصائيات</h2>
              <p className="text-muted-foreground">نظرة عامة على أداء المتجر</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-2 border-primary/20 shadow-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    إجمالي المنتجات
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <p className="text-3xl font-bold text-foreground">{totalProducts}</p>
                    <Package className="h-8 w-8 text-primary" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-primary/20 shadow-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    إجمالي الطلبات
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <p className="text-3xl font-bold text-foreground">{totalOrders}</p>
                    <ShoppingBag className="h-8 w-8 text-primary" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-orange-200 shadow-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    طلبات قيد الانتظار
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <p className="text-3xl font-bold text-orange-600">{pendingOrders}</p>
                    <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                      <span className="text-orange-600 font-bold">!</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-green-200 shadow-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    طلبات مكتملة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <p className="text-3xl font-bold text-green-600">{completedOrders}</p>
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="text-green-600 font-bold">✓</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-2 border-primary/20 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">إجمالي الإيرادات</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-4xl font-bold text-primary">
                  {(totalRevenue / 100).toLocaleString("ar-IQ")} د.ع
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  من {totalOrders} طلب
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-primary/20 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">روابط سريعة</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <a href="/" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="w-full justify-start">
                    عرض المتجر
                  </Button>
                </a>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setActiveTab("products")}
                >
                  إدارة المنتجات
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => setActiveTab("orders")}
                >
                  إدارة الطلبات
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "products" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-2">إدارة المنتجات</h2>
              <p className="text-muted-foreground">إضافة وتعديل وحذف المنتجات</p>
            </div>
            <ProductsManagement />
          </div>
        )}

        {activeTab === "orders" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-3xl font-bold text-foreground mb-2">إدارة الطلبات</h2>
              <p className="text-muted-foreground">متابعة وتحديث حالة الطلبات</p>
            </div>
            <OrdersManagement />
          </div>
        )}
      </main>
    </div>
  );
}
