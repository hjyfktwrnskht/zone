import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_TITLE, getLoginUrl } from "@/const";
import { Loader2, ShieldCheck, Lock } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function AdminLogin() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Check if password gate is passed
  useEffect(() => {
    const isPasswordVerified = sessionStorage.getItem("admin_password_verified");
    if (isPasswordVerified !== "true") {
      setLocation("/admin");
    }
  }, [setLocation]);

  useEffect(() => {
    if (!loading && isAuthenticated && user?.role === "admin") {
      setLocation("/admin/dashboard");
    }
  }, [loading, isAuthenticated, user, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-primary/5 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-primary/5 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <ShieldCheck className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="text-3xl font-bold">لوحة التحكم الإدارية</CardTitle>
          <CardDescription className="text-base">
            {APP_TITLE}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-muted/50 p-4 rounded-lg border border-border">
            <div className="flex items-start gap-3">
              <Lock className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-medium mb-1">وصول محمي</p>
                <p className="text-sm text-muted-foreground">
                  هذه الصفحة مخصصة للمديرين فقط. يرجى تسجيل الدخول بحساب مدير للمتابعة.
                </p>
              </div>
            </div>
          </div>

          <Button
            className="w-full"
            size="lg"
            onClick={() => {
              window.location.href = getLoginUrl();
            }}
          >
            <ShieldCheck className="ml-2 h-5 w-5" />
            تسجيل الدخول كمدير
          </Button>

          <div className="text-center">
            <a
              href="/"
              className="text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              العودة إلى المتجر ←
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
