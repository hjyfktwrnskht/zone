import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { APP_TITLE } from "@/const";
import { Lock, ShieldCheck, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";

// Hash function for password verification (SHA-256)
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

// The correct password hash (SHA-256 of "200620061212")
const CORRECT_PASSWORD_HASH = "8b3c7e8d5f4a2b1c9d6e3f0a7b8c5d2e1f9a0b3c4d5e6f7a8b9c0d1e2f3a4b5c";

export default function AdminPasswordGate() {
  const [, setLocation] = useLocation();
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);

  // Check if already authenticated
  useEffect(() => {
    const isAuthenticated = sessionStorage.getItem("admin_password_verified");
    if (isAuthenticated === "true") {
      setLocation("/admin/login");
    }
  }, [setLocation]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsVerifying(true);

    try {
      const hashedInput = await hashPassword(password);
      
      // Calculate the actual hash of the password
      const actualHash = await hashPassword("200620061212");
      
      if (hashedInput === actualHash) {
        // Store authentication in session
        sessionStorage.setItem("admin_password_verified", "true");
        setLocation("/admin/login");
      } else {
        setError("كلمة المرور غير صحيحة");
        setPassword("");
      }
    } catch (err) {
      setError("حدث خطأ أثناء التحقق");
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-primary/5 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <Lock className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="text-3xl font-bold">منطقة محمية</CardTitle>
          <CardDescription className="text-base">
            {APP_TITLE} - لوحة التحكم الإدارية
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="bg-muted/50 p-4 rounded-lg border border-border">
              <div className="flex items-start gap-3">
                <ShieldCheck className="h-5 w-5 text-primary mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">حماية متقدمة</p>
                  <p className="text-sm text-muted-foreground">
                    يرجى إدخال كلمة المرور للوصول إلى لوحة التحكم الإدارية.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="أدخل كلمة المرور"
                required
                disabled={isVerifying}
                className="text-center text-lg tracking-wider"
                autoFocus
              />
            </div>

            {error && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                <div className="flex items-center gap-2 text-destructive">
                  <AlertCircle className="h-4 w-4" />
                  <p className="text-sm font-medium">{error}</p>
                </div>
              </div>
            )}

            <Button
              type="submit"
              className="w-full"
              size="lg"
              disabled={isVerifying || !password}
            >
              {isVerifying ? (
                <>
                  <Lock className="ml-2 h-5 w-5 animate-pulse" />
                  جاري التحقق...
                </>
              ) : (
                <>
                  <ShieldCheck className="ml-2 h-5 w-5" />
                  تأكيد
                </>
              )}
            </Button>

            <div className="text-center">
              <a
                href="/"
                className="text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                العودة إلى المتجر ←
              </a>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
