import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { CheckCircle, Package, Mail, Phone, MapPin, CreditCard } from "lucide-react";
import { Link, useParams } from "wouter";
import { APP_TITLE } from "@/const";

export default function OrderConfirmation() {
  const params = useParams();
  const orderNumber = params.orderNumber || "";
  
  const { data: orderData, isLoading } = trpc.orders.getByNumber.useQuery({ orderNumber });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container py-4">
            <h1 className="text-2xl font-bold text-foreground">{APP_TITLE}</h1>
          </div>
        </header>
        <div className="container py-8">
          <div className="animate-pulse max-w-2xl mx-auto">
            <div className="h-8 bg-muted rounded w-1/3 mb-4" />
            <div className="h-64 bg-muted rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (!orderData) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container py-4">
            <h1 className="text-2xl font-bold text-foreground">{APP_TITLE}</h1>
          </div>
        </header>
        <div className="container py-16 text-center">
          <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-foreground mb-2">الطلب غير موجود</h2>
          <p className="text-muted-foreground mb-6">لم نتمكن من العثور على الطلب المطلوب</p>
          <Link href="/">
            <Button>العودة للرئيسية</Button>
          </Link>
        </div>
      </div>
    );
  }

  const order = orderData;
  const statusColors = {
    pending: "default",
    processing: "secondary",
    completed: "default",
    cancelled: "destructive",
  } as const;

  const statusLabels = {
    pending: "قيد الانتظار",
    processing: "قيد المعالجة",
    completed: "مكتمل",
    cancelled: "ملغي",
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container py-4">
          <h1 className="text-2xl font-bold text-foreground">{APP_TITLE}</h1>
        </div>
      </header>

      <div className="container py-8">
        <div className="max-w-2xl mx-auto">
          {/* Success Message */}
          <div className="text-center mb-8">
            <CheckCircle className="h-16 w-16 text-primary mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-foreground mb-2">
              تم إنشاء الطلب بنجاح!
            </h2>
            <p className="text-muted-foreground">
              رقم الطلب: <span className="font-mono font-bold">{order.orderNumber}</span>
            </p>
          </div>

          {/* Order Details */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>تفاصيل الطلب</CardTitle>
                <Badge variant={statusColors[order.status]}>
                  {statusLabels[order.status]}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Order Items */}
              <div>
                <h3 className="font-semibold mb-2">المنتجات:</h3>
                {order.items.map((item) => (
                  <div key={item.id} className="flex justify-between items-center py-2 border-b">
                    <div>
                      <p className="font-medium">{item.productName}</p>
                      <p className="text-sm text-muted-foreground">الكمية: {item.quantity}</p>
                    </div>
                    <p className="font-semibold">
                      {((item.price * item.quantity) / 100).toLocaleString("ar-IQ")} د.ع
                    </p>
                  </div>
                ))}
              </div>

              {/* Total */}
              <div className="flex justify-between items-center pt-4 border-t">
                <span className="text-lg font-semibold">المجموع الكلي:</span>
                <span className="text-2xl font-bold text-primary">
                  {(order.totalAmount / 100).toLocaleString("ar-IQ")} د.ع
                </span>
              </div>

              {/* Payment Method */}
              <div className="flex items-center gap-2 pt-4">
                <CreditCard className="h-5 w-5 text-muted-foreground" />
                <span className="font-medium">طريقة الدفع:</span>
                <span>
                  {order.paymentMethod === "asiaCel" && "آسيا سيل"}
                  {order.paymentMethod === "masterCard" && "ماستر كارد"}
                  {order.paymentMethod === "cashOnDelivery" && "الدفع عند الاستلام"}
                </span>
              </div>

              {/* Digital Product Info */}
              {order.productType === "digital" && order.email && (
                <div className="bg-primary/10 p-4 rounded-md">
                  <div className="flex items-start gap-2">
                    <Mail className="h-5 w-5 text-primary mt-0.5" />
                    <div>
                      <p className="font-semibold text-primary">منتج رقمي</p>
                      <p className="text-sm">
                        سيتم إرسال المنتج إلى البريد الإلكتروني: <span className="font-mono">{order.email}</span>
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        يرجى التحقق من صندوق الوارد أو البريد المزعج
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Physical Product Info */}
              {order.productType === "physical" && (
                <div className="bg-muted/50 p-4 rounded-md space-y-3">
                  <div>
                    <p className="font-semibold mb-2">معلومات الشحن:</p>
                    <div className="space-y-2 text-sm">
                      {order.customerName && (
                        <div className="flex items-center gap-2">
                          <Package className="h-4 w-4 text-muted-foreground" />
                          <span>{order.customerName}</span>
                        </div>
                      )}
                      {order.phone && (
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <span dir="ltr">{order.phone}</span>
                        </div>
                      )}
                      {order.city && (
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span>{order.city}</span>
                        </div>
                      )}
                      {order.address && (
                        <div className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                          <span>{order.address}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  {order.notes && (
                    <div>
                      <p className="font-semibold mb-1">ملاحظات:</p>
                      <p className="text-sm text-muted-foreground">{order.notes}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Order Date */}
              <div className="text-sm text-muted-foreground pt-4 border-t">
                تاريخ الطلب: {new Date(order.createdAt).toLocaleString("ar-IQ")}
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex gap-4">
            <Link href="/" className="flex-1">
              <Button variant="outline" className="w-full">
                العودة للرئيسية
              </Button>
            </Link>
            <Button
              variant="default"
              className="flex-1"
              onClick={() => window.print()}
            >
              طباعة الطلب
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
