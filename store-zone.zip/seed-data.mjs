import { drizzle } from "drizzle-orm/mysql2";
import { products } from "./drizzle/schema.js";

const db = drizzle(process.env.DATABASE_URL);

const sampleProducts = [
  {
    name: "بطاقة شحن آيتونز 25$",
    description: "بطاقة شحن رقمية لمتجر آيتونز بقيمة 25 دولار أمريكي. يتم إرسال الكود فوراً عبر البريد الإلكتروني.",
    price: 3500000, // 35,000 IQD
    type: "digital",
    imageUrl: "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=500&h=500&fit=crop",
    stock: 50,
    isActive: 1,
  },
  {
    name: "بطاقة شحن بلايستيشن 50$",
    description: "بطاقة شحن رقمية لمتجر بلايستيشن بقيمة 50 دولار. استمتع بألعابك المفضلة!",
    price: 7000000, // 70,000 IQD
    type: "digital",
    imageUrl: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=500&h=500&fit=crop",
    stock: 30,
    isActive: 1,
  },
  {
    name: "سماعات لاسلكية AirPods Pro",
    description: "سماعات أبل اللاسلكية الأصلية مع خاصية إلغاء الضوضاء. توصيل سريع لجميع أنحاء العراق.",
    price: 35000000, // 350,000 IQD
    type: "physical",
    imageUrl: "https://images.unsplash.com/photo-1606841837239-c5a1a4a07af7?w=500&h=500&fit=crop",
    stock: 15,
    isActive: 1,
  },
  {
    name: "ساعة ذكية Apple Watch Series 9",
    description: "أحدث إصدار من ساعة أبل الذكية مع مميزات صحية متقدمة. ضمان سنة.",
    price: 60000000, // 600,000 IQD
    type: "physical",
    imageUrl: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=500&h=500&fit=crop",
    stock: 8,
    isActive: 1,
  },
  {
    name: "اشتراك Netflix Premium - شهر",
    description: "اشتراك نتفليكس بريميوم لمدة شهر كامل. 4 شاشات بجودة 4K. يتم التفعيل فوراً.",
    price: 2000000, // 20,000 IQD
    type: "digital",
    imageUrl: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=500&h=500&fit=crop",
    stock: 100,
    isActive: 1,
  },
  {
    name: "لابتوب Dell XPS 13",
    description: "لابتوب ديل الاحترافي بمعالج Intel Core i7 وذاكرة 16GB RAM. مثالي للعمل والدراسة.",
    price: 150000000, // 1,500,000 IQD
    type: "physical",
    imageUrl: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=500&h=500&fit=crop",
    stock: 5,
    isActive: 1,
  },
];

async function seed() {
  try {
    console.log("🌱 بدء إضافة البيانات التجريبية...");
    
    for (const product of sampleProducts) {
      await db.insert(products).values(product);
      console.log(`✅ تمت إضافة: ${product.name}`);
    }
    
    console.log("✨ تم إضافة جميع المنتجات التجريبية بنجاح!");
    process.exit(0);
  } catch (error) {
    console.error("❌ خطأ أثناء إضافة البيانات:", error);
    process.exit(1);
  }
}

seed();
